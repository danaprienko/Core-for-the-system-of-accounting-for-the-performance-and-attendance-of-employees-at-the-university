import pytest

from app.domain.entities import AttendanceRecord, Course, Grade, Student


def test_student_requires_name_and_group():
    with pytest.raises(ValueError):
        Student("s1", " ", "G1")
    with pytest.raises(ValueError):
        Student("s1", "Ada", " ")


def test_grade_must_be_between_zero_and_one_hundred():
    with pytest.raises(ValueError):
        Grade.create("g1", "s1", "c1", -1, "teacher")
    with pytest.raises(ValueError):
        Grade.create("g1", "s1", "c1", 101, "teacher")


def test_valid_grade_is_created():
    grade = Grade.create("g1", "s1", "c1", 88, "teacher")
    assert grade.value == 88
    assert grade.student_id == "s1"
    assert grade.recorded_at is not None


def test_attendance_requires_recorder():
    with pytest.raises(ValueError):
        AttendanceRecord.create("a1", "s1", "c1", True, " ")


def test_course_requires_name():
    with pytest.raises(ValueError):
        Course("c1", "")
