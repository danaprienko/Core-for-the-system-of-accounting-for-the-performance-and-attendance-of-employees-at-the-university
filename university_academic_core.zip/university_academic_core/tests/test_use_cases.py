import pytest

from app.application.use_cases import GetStudentPerformance, MarkAttendance, NotFoundError, RecordGrade
from app.domain.entities import Course, Student
from app.infrastructure.memory_repositories import (
    InMemoryAttendanceRepository, InMemoryCourseRepository, InMemoryGradeRepository,
    InMemoryStudentRepository,
)


def setup_repositories():
    students = InMemoryStudentRepository()
    courses = InMemoryCourseRepository()
    grades = InMemoryGradeRepository()
    attendance = InMemoryAttendanceRepository()
    students.add(Student("s1", "Ada Lovelace", "CS-1"))
    courses.add(Course("c1", "Programming"))
    return students, courses, grades, attendance


def test_record_grade_succeeds_for_known_student_and_course():
    students, courses, grades, _ = setup_repositories()
    use_case = RecordGrade(students, courses, grades)
    grade = use_case.execute("g1", "s1", "c1", 90, "teacher-1")
    assert grade.value == 90
    assert len(grades.list_for_student("s1")) == 1


def test_record_grade_fails_for_unknown_student():
    students, courses, grades, _ = setup_repositories()
    use_case = RecordGrade(students, courses, grades)
    with pytest.raises(NotFoundError):
        use_case.execute("g1", "missing", "c1", 90, "teacher-1")


def test_attendance_and_performance_report():
    students, courses, grades, attendance = setup_repositories()
    RecordGrade(students, courses, grades).execute("g1", "s1", "c1", 80, "teacher-1")
    RecordGrade(students, courses, grades).execute("g2", "s1", "c1", 100, "teacher-1")
    marker = MarkAttendance(students, courses, attendance)
    marker.execute("a1", "s1", "c1", True, "teacher-1")
    marker.execute("a2", "s1", "c1", False, "teacher-1")

    report = GetStudentPerformance(students, grades, attendance).execute("s1")
    assert report.average_grade == 90
    assert report.attendance_total == 2
    assert report.attendance_present == 1
    assert report.attendance_rate == 50


def test_performance_fails_for_unknown_student():
    students, _, grades, attendance = setup_repositories()
    with pytest.raises(NotFoundError):
        GetStudentPerformance(students, grades, attendance).execute("missing")
