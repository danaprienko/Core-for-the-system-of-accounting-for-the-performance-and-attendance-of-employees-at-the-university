from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_api_flow_create_student_course_grade_and_report():
    # Уникальные ID позволяют запускать тесты повторно в одном процессе.
    student_id = "api-test-student"
    course_id = "api-test-course"
    grade_id = "api-test-grade"

    student = client.post("/students", json={
        "student_id": student_id,
        "full_name": "Test Student",
        "group_name": "TEST-1",
    })
    assert student.status_code == 201

    course = client.post("/courses", json={
        "course_id": course_id,
        "name": "Test Course",
    })
    assert course.status_code == 201

    grade = client.post("/grades", json={
        "grade_id": grade_id,
        "student_id": student_id,
        "course_id": course_id,
        "value": 95,
        "recorded_by": "teacher-test",
    })
    assert grade.status_code == 201
    assert grade.json()["value"] == 95

    report = client.get(f"/students/{student_id}/performance")
    assert report.status_code == 200
    assert report.json()["average_grade"] == 95
