"""Автоматическая проверка: Domain не должен импортировать внешние слои."""

import ast
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DOMAIN = ROOT / "app" / "domain"


def test_domain_does_not_import_outer_layers():
    forbidden = ("app.application", "app.infrastructure", "app.presentation")
    violations = []

    for path in DOMAIN.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module]
            else:
                continue
            for name in names:
                if any(name == prefix or name.startswith(prefix + ".") for prefix in forbidden):
                    violations.append(f"{path.relative_to(ROOT)} imports {name}")

    assert not violations, "Нарушено направление зависимостей:\\n" + "\\n".join(violations)
