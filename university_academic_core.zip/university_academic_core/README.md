# Ядро системы учёта успеваемости и посещаемости

Учебный проект для лабораторной работы №2 «Реалізація багатошарового ядра системи».

## Что реализовано

- **Domain** — доменные сущности и правила предметной области.
- **Application** — сценарии: выставить оценку, отметить посещаемость, посмотреть успеваемость.
- **Infrastructure** — in-memory реализации репозиториев (данные хранятся в памяти процесса).
- **Presentation** — минимальный HTTP API на FastAPI.
- **Dependency Injection** — единая точка сборки зависимостей в `app/bootstrap.py`.
- **Тесты** — проверка бизнес-правил без базы данных и автоматическая проверка направления зависимостей.

Для этой лабораторной PostgreSQL, SQLAlchemy, Celery, Redis и React намеренно не подключены: методичка допускает in-memory хранилища, а постоянное хранилище можно добавить позже.

## Требования

Python 3.12 или новее.

## Запуск в Windows (PowerShell)

Откройте терминал в папке проекта и выполните:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[dev]"
uvicorn app.main:app --reload
```

Если PowerShell запрещает активацию окружения, можно запускать команды через `.venv\Scripts\python.exe` и `.venv\Scripts\uvicorn.exe`.

Откройте:
- API: http://127.0.0.1:8000
- Swagger UI: http://127.0.0.1:8000/docs
- Проверка состояния: http://127.0.0.1:8000/health

## Запуск тестов

```powershell
pytest
```

Ожидается, что все тесты пройдут. Тесты не требуют PostgreSQL.

## Примеры запросов

### 1. Создать студента

В Swagger UI откройте `POST /students` и отправьте:

```json
{
  "student_id": "stu-001",
  "full_name": "Иван Петренко",
  "group_name": "КН-21"
}
```

### 2. Создать дисциплину

`POST /courses`

```json
{
  "course_id": "course-001",
  "name": "Основы программирования"
}
```

### 3. Выставить оценку

`POST /grades`

```json
{
  "grade_id": "grade-001",
  "student_id": "stu-001",
  "course_id": "course-001",
  "value": 90,
  "recorded_by": "teacher-001"
}
```

Оценка должна быть от 0 до 100 включительно.

### 4. Отметить посещаемость

`POST /attendance`

```json
{
  "attendance_id": "att-001",
  "student_id": "stu-001",
  "course_id": "course-001",
  "was_present": true,
  "recorded_by": "teacher-001"
}
```

### 5. Посмотреть успеваемость

`GET /students/stu-001/performance`

Ответ включает оценки, средний балл и статистику посещаемости.

## Архитектура

```text
Presentation (FastAPI)
        |
        v
Application (use cases)
        |
        v
Domain (entities + repository interfaces)
        ^
        |
Infrastructure (in-memory repository implementations)
```

Правило зависимостей: `Domain` не импортирует `Application`, `Infrastructure` или `Presentation`. Application использует интерфейсы репозиториев из Domain. Infrastructure реализует эти интерфейсы.

## Ограничения учебной версии

- In-memory данные пропадают после перезапуска приложения.
- Аутентификация и авторизация не реализованы.
- Нет реального подключения к PostgreSQL.
- Это минимальное ядро, а не законченная промышленная система.
