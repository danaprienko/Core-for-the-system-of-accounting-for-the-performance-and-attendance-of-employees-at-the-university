"""Простые реализации репозиториев в оперативной памяти."""

from app.domain.entities import AttendanceRecord, Course, Grade, Student
from app.domain.repositories import (
    AttendanceRepository,
    CourseRepository,
    GradeRepository,
    StudentRepository,
)


class InMemoryStudentRepository(StudentRepository):
    def __init__(self) -> None:
        self._items: dict[str, Student] = {}

    def add(self, student: Student) -> None:
        if student.student_id in self._items:
            raise ValueError(f"Студент '{student.student_id}' уже существует")
        self._items[student.student_id] = student

    def get(self, student_id: str) -> Student | None:
        return self._items.get(student_id)


class InMemoryCourseRepository(CourseRepository):
    def __init__(self) -> None:
        self._items: dict[str, Course] = {}

    def add(self, course: Course) -> None:
        if course.course_id in self._items:
            raise ValueError(f"Дисциплина '{course.course_id}' уже существует")
        self._items[course.course_id] = course

    def get(self, course_id: str) -> Course | None:
        return self._items.get(course_id)


class InMemoryGradeRepository(GradeRepository):
    def __init__(self) -> None:
        self._items: dict[str, Grade] = {}

    def add(self, grade: Grade) -> None:
        if any(item.grade_id == grade.grade_id for item in self._items.values()):
            raise ValueError(f"Оценка '{grade.grade_id}' уже существует")
        self._items[grade.grade_id] = grade

    def list_for_student(self, student_id: str) -> list[Grade]:
        return [item for item in self._items.values() if item.student_id == student_id]


class InMemoryAttendanceRepository(AttendanceRepository):
    def __init__(self) -> None:
        self._items: dict[str, AttendanceRecord] = {}

    def add(self, record: AttendanceRecord) -> None:
        if any(item.attendance_id == record.attendance_id for item in self._items.values()):
            raise ValueError(f"Запись посещаемости '{record.attendance_id}' уже существует")
        self._items[record.attendance_id] = record

    def list_for_student(self, student_id: str) -> list[AttendanceRecord]:
        return [
            item for item in self._items.values()
            if item.student_id == student_id
        ]
