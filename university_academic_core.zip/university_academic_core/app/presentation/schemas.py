"""Pydantic-схемы HTTP API. Не используются в Domain."""

from datetime import datetime
from pydantic import BaseModel, Field


class StudentCreate(BaseModel):
    student_id: str = Field(min_length=1, max_length=64)
    full_name: str = Field(min_length=1, max_length=200)
    group_name: str = Field(min_length=1, max_length=100)


class CourseCreate(BaseModel):
    course_id: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=200)


class GradeCreate(BaseModel):
    grade_id: str = Field(min_length=1, max_length=64)
    student_id: str = Field(min_length=1, max_length=64)
    course_id: str = Field(min_length=1, max_length=64)
    value: int = Field(ge=0, le=100)
    recorded_by: str = Field(min_length=1, max_length=64)


class AttendanceCreate(BaseModel):
    attendance_id: str = Field(min_length=1, max_length=64)
    student_id: str = Field(min_length=1, max_length=64)
    course_id: str = Field(min_length=1, max_length=64)
    was_present: bool
    recorded_by: str = Field(min_length=1, max_length=64)


class StudentOut(BaseModel):
    student_id: str
    full_name: str
    group_name: str


class CourseOut(BaseModel):
    course_id: str
    name: str


class GradeOut(BaseModel):
    grade_id: str
    student_id: str
    course_id: str
    value: int
    recorded_by: str
    recorded_at: datetime


class AttendanceOut(BaseModel):
    attendance_id: str
    student_id: str
    course_id: str
    was_present: bool
    recorded_by: str
    recorded_at: datetime


class PerformanceOut(BaseModel):
    student_id: str
    student_name: str
    group_name: str
    grades: list[GradeOut]
    average_grade: float | None
    attendance_total: int
    attendance_present: int
    attendance_rate: float | None
