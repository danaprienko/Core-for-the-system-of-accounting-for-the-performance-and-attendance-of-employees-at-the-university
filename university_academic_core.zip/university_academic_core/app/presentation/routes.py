"""HTTP-слой: проверяет входные данные и вызывает сценарии приложения."""

from fastapi import APIRouter, HTTPException, status

from app.application.use_cases import ConflictError, NotFoundError
from app.bootstrap import Container
from app.domain.entities import Course, Student
from app.presentation.schemas import (
    AttendanceCreate, AttendanceOut, CourseCreate, CourseOut, GradeCreate,
    GradeOut, PerformanceOut, StudentCreate, StudentOut,
)


def create_router(container: Container) -> APIRouter:
    router = APIRouter()

    @router.post("/students", response_model=StudentOut, status_code=status.HTTP_201_CREATED, tags=["students"])
    def create_student(payload: StudentCreate):
        try:
            student = Student(**payload.model_dump())
            container.students.add(student)
            return student
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @router.get("/students/{student_id}", response_model=StudentOut, tags=["students"])
    def get_student(student_id: str):
        student = container.students.get(student_id)
        if student is None:
            raise HTTPException(status_code=404, detail="Студент не найден")
        return student

    @router.post("/courses", response_model=CourseOut, status_code=status.HTTP_201_CREATED, tags=["courses"])
    def create_course(payload: CourseCreate):
        try:
            course = Course(**payload.model_dump())
            container.courses.add(course)
            return course
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @router.post("/grades", response_model=GradeOut, status_code=status.HTTP_201_CREATED, tags=["grades"])
    def record_grade(payload: GradeCreate):
        try:
            return container.record_grade.execute(**payload.model_dump())
        except NotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ConflictError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @router.post("/attendance", response_model=AttendanceOut, status_code=status.HTTP_201_CREATED, tags=["attendance"])
    def mark_attendance(payload: AttendanceCreate):
        try:
            return container.mark_attendance.execute(**payload.model_dump())
        except NotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ConflictError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @router.get("/students/{student_id}/performance", response_model=PerformanceOut, tags=["reports"])
    def student_performance(student_id: str):
        try:
            return container.get_student_performance.execute(student_id).__dict__
        except NotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    return router
