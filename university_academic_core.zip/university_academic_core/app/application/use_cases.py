"""Сценарии приложения: координируют домен и интерфейсы репозиториев."""

from dataclasses import dataclass

from app.domain.entities import AttendanceRecord, Grade
from app.domain.repositories import (
    AttendanceRepository,
    CourseRepository,
    GradeRepository,
    StudentRepository,
)


class NotFoundError(Exception):
    """Запрошенная доменная сущность не найдена."""


class ConflictError(Exception):
    """Операция конфликтует с уже существующими данными."""


@dataclass(frozen=True)
class StudentPerformance:
    student_id: str
    student_name: str
    group_name: str
    grades: list[Grade]
    average_grade: float | None
    attendance_total: int
    attendance_present: int
    attendance_rate: float | None


class RecordGrade:
    def __init__(
        self,
        students: StudentRepository,
        courses: CourseRepository,
        grades: GradeRepository,
    ) -> None:
        self._students = students
        self._courses = courses
        self._grades = grades

    def execute(
        self, grade_id: str, student_id: str, course_id: str,
        value: int, recorded_by: str,
    ) -> Grade:
        if self._students.get(student_id) is None:
            raise NotFoundError(f"Студент '{student_id}' не найден")
        if self._courses.get(course_id) is None:
            raise NotFoundError(f"Дисциплина '{course_id}' не найдена")
        if any(g.grade_id == grade_id for g in self._grades.list_for_student(student_id)):
            raise ConflictError(f"Оценка '{grade_id}' уже существует")
        grade = Grade.create(grade_id, student_id, course_id, value, recorded_by)
        self._grades.add(grade)
        return grade


class MarkAttendance:
    def __init__(
        self,
        students: StudentRepository,
        courses: CourseRepository,
        attendance: AttendanceRepository,
    ) -> None:
        self._students = students
        self._courses = courses
        self._attendance = attendance

    def execute(
        self, attendance_id: str, student_id: str, course_id: str,
        was_present: bool, recorded_by: str,
    ) -> AttendanceRecord:
        if self._students.get(student_id) is None:
            raise NotFoundError(f"Студент '{student_id}' не найден")
        if self._courses.get(course_id) is None:
            raise NotFoundError(f"Дисциплина '{course_id}' не найдена")
        if any(
            item.attendance_id == attendance_id
            for item in self._attendance.list_for_student(student_id)
        ):
            raise ConflictError(f"Запись посещаемости '{attendance_id}' уже существует")
        record = AttendanceRecord.create(
            attendance_id, student_id, course_id, was_present, recorded_by
        )
        self._attendance.add(record)
        return record


class GetStudentPerformance:
    def __init__(
        self,
        students: StudentRepository,
        grades: GradeRepository,
        attendance: AttendanceRepository,
    ) -> None:
        self._students = students
        self._grades = grades
        self._attendance = attendance

    def execute(self, student_id: str) -> StudentPerformance:
        student = self._students.get(student_id)
        if student is None:
            raise NotFoundError(f"Студент '{student_id}' не найден")

        grades = self._grades.list_for_student(student_id)
        records = self._attendance.list_for_student(student_id)
        average = (
            round(sum(item.value for item in grades) / len(grades), 2)
            if grades else None
        )
        present = sum(1 for item in records if item.was_present)
        rate = round(present / len(records) * 100, 2) if records else None

        return StudentPerformance(
            student_id=student.student_id,
            student_name=student.full_name,
            group_name=student.group_name,
            grades=grades,
            average_grade=average,
            attendance_total=len(records),
            attendance_present=present,
            attendance_rate=rate,
        )
