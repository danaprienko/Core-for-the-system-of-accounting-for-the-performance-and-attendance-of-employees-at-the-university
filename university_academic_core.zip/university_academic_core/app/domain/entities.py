"""Доменная модель. Здесь нет зависимости от FastAPI или хранилища."""

from dataclasses import dataclass
from datetime import datetime, timezone


@dataclass(frozen=True)
class Student:
    student_id: str
    full_name: str
    group_name: str

    def __post_init__(self) -> None:
        if not self.student_id.strip():
            raise ValueError("ID студента не может быть пустым")
        if not self.full_name.strip():
            raise ValueError("Имя студента не может быть пустым")
        if not self.group_name.strip():
            raise ValueError("Учебная группа не может быть пустой")


@dataclass(frozen=True)
class Course:
    course_id: str
    name: str

    def __post_init__(self) -> None:
        if not self.course_id.strip():
            raise ValueError("ID дисциплины не может быть пустым")
        if not self.name.strip():
            raise ValueError("Название дисциплины не может быть пустым")


@dataclass(frozen=True)
class Grade:
    grade_id: str
    student_id: str
    course_id: str
    value: int
    recorded_by: str
    recorded_at: datetime

    def __post_init__(self) -> None:
        if not self.grade_id.strip():
            raise ValueError("ID оценки не может быть пустым")
        if not self.student_id.strip() or not self.course_id.strip():
            raise ValueError("Оценка должна быть связана со студентом и дисциплиной")
        if not 0 <= self.value <= 100:
            raise ValueError("Оценка должна быть в диапазоне от 0 до 100")
        if not self.recorded_by.strip():
            raise ValueError("Не указан пользователь, выставивший оценку")

    @classmethod
    def create(
        cls, grade_id: str, student_id: str, course_id: str,
        value: int, recorded_by: str,
    ) -> "Grade":
        return cls(
            grade_id=grade_id,
            student_id=student_id,
            course_id=course_id,
            value=value,
            recorded_by=recorded_by,
            recorded_at=datetime.now(timezone.utc),
        )


@dataclass(frozen=True)
class AttendanceRecord:
    attendance_id: str
    student_id: str
    course_id: str
    was_present: bool
    recorded_by: str
    recorded_at: datetime

    def __post_init__(self) -> None:
        if not self.attendance_id.strip():
            raise ValueError("ID записи посещаемости не может быть пустым")
        if not self.student_id.strip() or not self.course_id.strip():
            raise ValueError("Посещаемость должна быть связана со студентом и дисциплиной")
        if not self.recorded_by.strip():
            raise ValueError("Не указан пользователь, отметивший посещаемость")

    @classmethod
    def create(
        cls, attendance_id: str, student_id: str, course_id: str,
        was_present: bool, recorded_by: str,
    ) -> "AttendanceRecord":
        return cls(
            attendance_id=attendance_id,
            student_id=student_id,
            course_id=course_id,
            was_present=was_present,
            recorded_by=recorded_by,
            recorded_at=datetime.now(timezone.utc),
        )
