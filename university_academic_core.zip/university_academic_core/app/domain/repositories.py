"""Интерфейсы репозиториев. Domain не знает о способе хранения данных."""

from abc import ABC, abstractmethod

from app.domain.entities import AttendanceRecord, Course, Grade, Student


class StudentRepository(ABC):
    @abstractmethod
    def add(self, student: Student) -> None: ...

    @abstractmethod
    def get(self, student_id: str) -> Student | None: ...


class CourseRepository(ABC):
    @abstractmethod
    def add(self, course: Course) -> None: ...

    @abstractmethod
    def get(self, course_id: str) -> Course | None: ...


class GradeRepository(ABC):
    @abstractmethod
    def add(self, grade: Grade) -> None: ...

    @abstractmethod
    def list_for_student(self, student_id: str) -> list[Grade]: ...


class AttendanceRepository(ABC):
    @abstractmethod
    def add(self, record: AttendanceRecord) -> None: ...

    @abstractmethod
    def list_for_student(self, student_id: str) -> list[AttendanceRecord]: ...
