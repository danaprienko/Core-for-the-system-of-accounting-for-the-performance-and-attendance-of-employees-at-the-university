"""Единая точка конфигурации зависимостей (composition root)."""

from dataclasses import dataclass

from app.application.use_cases import (
    GetStudentPerformance,
    MarkAttendance,
    RecordGrade,
)
from app.domain.repositories import (
    AttendanceRepository,
    CourseRepository,
    GradeRepository,
    StudentRepository,
)
from app.infrastructure.memory_repositories import (
    InMemoryAttendanceRepository,
    InMemoryCourseRepository,
    InMemoryGradeRepository,
    InMemoryStudentRepository,
)


@dataclass(frozen=True)
class Container:
    students: StudentRepository
    courses: CourseRepository
    grades: GradeRepository
    attendance: AttendanceRepository
    record_grade: RecordGrade
    mark_attendance: MarkAttendance
    get_student_performance: GetStudentPerformance


def build_container() -> Container:
    students = InMemoryStudentRepository()
    courses = InMemoryCourseRepository()
    grades = InMemoryGradeRepository()
    attendance = InMemoryAttendanceRepository()

    return Container(
        students=students,
        courses=courses,
        grades=grades,
        attendance=attendance,
        record_grade=RecordGrade(students, courses, grades),
        mark_attendance=MarkAttendance(students, courses, attendance),
        get_student_performance=GetStudentPerformance(students, grades, attendance),
    )
