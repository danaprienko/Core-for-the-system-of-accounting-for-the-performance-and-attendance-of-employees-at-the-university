from fastapi import FastAPI

from app.bootstrap import build_container
from app.presentation.routes import create_router

app = FastAPI(
    title="University Academic Core",
    description="Учебное ядро учёта успеваемости и посещаемости",
    version="1.0.0",
)

container = build_container()
app.include_router(create_router(container))


@app.get("/health", tags=["system"])
def health() -> dict[str, str]:
    return {"status": "ok"}
